from tkinter import *
from PIL import ImageTk,Image
import calendar
def calender():
	root=Tk()
	root.iconbitmap(r"calender_image.ico")
	def calen():
		root.configure(bg='#fcfcec')
		root.title("Calender")

		firstnum=e.get()
		fnum=int(firstnum)
		mylabel1=Label(root,text=calendar.month(fnum%100,1),font=("Consolas 10 bold"),bg="#fcfcec",fg="#cb464e")
		mylabel1.grid(row=1,column=0, padx = 20)

	myLabel= Label(root,text="Enter Year :- ",bg='#fcfcec',fg="#4b7fa4",font=("times", 20))
	myLabel.grid(row=0,column=1)
	e =Entry(root,width=50,bg="white",fg="black",border=10)
	e.grid(row=0,column=2)

	# myLabel1= Label(root,text="Enter Month :- ",bg='#fcfcec',fg="#4b7fa4",font=("times", 20))
	# myLabel1.grid(row=0,column=1)
	# e1 =Entry(root,width=50,bg="white",fg="black",border=10)
	# e1.grid(row=0,column=2)


	mybutton=Button(root,text="Go",bg='#cb464e',fg="#fcfcec",command=calen,font=("times",15))
	mybutton.grid(row=0,column=3)
	root.title('Calendar')
	root.mainloop()
calender()