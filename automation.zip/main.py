from tkinter import *


def start():

	def notepad():
		from notepad import notepad
		notepad()
		
	def alarm_clock():
		from clock import alarm_on
		alarm_on()

	def calculator():
		from calculator import calculator
		calculator()

	def calender():
		from calender import calender
		calender()

	root=Tk()
	root.geometry("1920x1080")
	img_cal1=PhotoImage(file="background.PNG")
	Label(root,image=img_cal1).pack()

	img_cal=PhotoImage(file="cal.PNG")
	cal=Button(root,image=img_cal,command=lambda :calculator())
	cal.place(x=20,y=15)

	img_note=PhotoImage(file="note1.PNG")
	note=Button(root,image=img_note,command=lambda :notepad())
	note.place(x=20,y=75)

	img_alarm=PhotoImage(file="alarm.PNG")
	alarm=Button(root,image=img_alarm,command=lambda :alarm_clock())
	alarm.place(x=20,y=135)

	img_exit=PhotoImage(file="exit.PNG")
	exit=Button(root,image=img_exit,command=lambda :quit())
	exit.place(x=20,y=835)

	img_calender=PhotoImage(file="calender_image.PNG")
	cal=Button(root,image=img_calender,command=lambda :calender())
	cal.place(x=20,y=185)

	# root.attributes('-fullscreen',True)

	root.mainloop()
start()